package com.cucumberFramework.stepdefinitions;

import com.cucumberFramework.helper.WaitHelper;
import com.cucumberFramework.pageObjects.RegistrationPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

import java.util.Properties;

import static com.cucumberFramework.testBase.TestBase.driver;
import static java.lang.System.getProperties;

public class RegistrationPageStepDefinitions {

    WaitHelper waitHelper = new WaitHelper(driver);

    Properties prop = getProperties();

    RegistrationPage registrationPage = new RegistrationPage(driver);

    @Then("I click on New User! Register Here button and wait for Registration page")
    public void i_click_on_new_user_register_here_button_and_wait_for_registration_page() {
        registrationPage.clickOnRegistration();
        waitHelper.WaitForElement(registrationPage.userName, 60);
    }
    @Then("I should see Registration Page")
    public void i_should_see_registration_page() {
        Assert.assertEquals(registrationPage.getRegisterHereText(), "Register Here");
    }
    @Then("I enter First Name")
    public void i_enter_first_name() {
        registrationPage.enterFirstName("jhon");
    }
    @Then("I enter Last Name")
    public void i_enter_last_name() {
        registrationPage.enterLastName("12345");
    }
    @Then("I enter Address")
    public void i_enter_address() {
        registrationPage.enterAddress("HN) 123 Street");
    }
    @Then("I enter Phone No")
    public void i_enter_phone_no() {
        registrationPage.enterPhoneNo("1234567890");
    }
    @Then("I enter Email Id")
    public void i_enter_email_id() {
            registrationPage.enterEmailID("test@gmail.com");
    }
    @When("I click on I AGREE FOR ALL TERMS & CONDITIONS! REGISTER ME")
    public void i_click_on_i_agree_for_all_terms_conditions_register_me() {
        registrationPage.clickOnAgreeAndSubmit();
    }
    @Then("I should verify whether registration is successful or not")
    public void i_should_verify_whether_registration_is_successful_or_not() {
        Assert.assertEquals(registrationPage.getRegistrationMsg(), "User Registered Successfully");
    }
}
