package com.cucumberFramework.pageObjects;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cucumberFramework.helper.WaitHelper;

public class LoginPage {

	private WebDriver driver;

	@FindBy(xpath="//a[contains(@href,'UserLogin')]")
	public WebElement loginAsUserButton;
	@FindBy(xpath="//input[@name='username']")
	public WebElement userName;
	
	@FindBy(xpath="//input[@name='password']")
	WebElement password;

	@FindBy(xpath="//input[contains(@value,'LOGIN AS USER')]")
	WebElement loginButton;

	@FindBy(xpath = "//div[contains(@class,'tab hd brown')]")
	WebElement loginMessage;
	
	WaitHelper waitHelper;

	public LoginPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
		//waitHelper.WaitForElement(userName, 60);
	}
	
	public void enterUserName(String userName){
		this.userName.sendKeys(userName);
	}
	
	public void enterPassword(String password){
		this.password.sendKeys(password);
	}
	
	public void clickLoginButton(){
		loginButton.click();
	}

	public void loginAsUser(){
		loginAsUserButton.click();
	}

	public String getLoginMessage(){
		return loginMessage.getText();
	}

}
